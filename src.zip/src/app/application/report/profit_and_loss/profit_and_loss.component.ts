import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'az-profit_and_loss',
  templateUrl: './profit_and_loss.component.html',
  styleUrls: ['./profit_and_loss.component.scss']
})
export class Profit_and_lossComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Delivery_challen_viewComponent } from './delivery_challen_view.component';

@NgModule({
  imports: [
    CommonModule,
    NgModule
  ],
  declarations: [Delivery_challen_viewComponent]
})
export class Delivery_challen_viewModule { }

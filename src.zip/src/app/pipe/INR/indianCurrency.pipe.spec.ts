/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { IndianCurrencyPipe } from './indianCurrency.pipe';

describe('Pipe: IndianCurrencye', () => {
  it('create an instance', () => {
    let pipe = new IndianCurrencyPipe();
    expect(pipe).toBeTruthy();
  });
});

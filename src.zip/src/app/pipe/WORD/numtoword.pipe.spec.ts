/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { NumtowordPipe } from './numtoword.pipe';

describe('Pipe: Numtoworde', () => {
  it('create an instance', () => {
    let pipe = new NumtowordPipe();
    expect(pipe).toBeTruthy();
  });
});

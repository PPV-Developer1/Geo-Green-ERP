import { Component, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'az-tabs-accordions',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './tabs-accordions.component.html'
})
export class TabsAccordionsComponent { }

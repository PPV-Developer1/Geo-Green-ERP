import { Component, ViewEncapsulation, OnInit } from '@angular/core';

@Component({
  selector: 'az-typography',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './typography.component.html',
  styleUrls: ['./typography.component.scss']
})
export class TypographyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'az-list-group',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './list-group.component.html'
})
export class ListGroupComponent { }

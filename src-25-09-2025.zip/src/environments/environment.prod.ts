export const environment = {
  production: true,
  // baseURL: 'https://geogreenenviro.com/geogreen_api/',
  baseURL: 'http://localhost/erp_api_raja/',
  authToken: 'ppvtech123'
};

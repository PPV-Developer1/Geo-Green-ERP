import { Component, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'az-buttons',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './buttons.component.html',
  styleUrls: ['./buttons.component.scss']
})
export class ButtonsComponent { }

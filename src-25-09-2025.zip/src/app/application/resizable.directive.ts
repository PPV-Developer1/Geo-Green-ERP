import { Directive } from '@angular/core';

@Directive({
  selector: '[appResizable]'
})
export class ResizableDirective {

  constructor() { }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'az-grn',
  templateUrl: './grn.component.html',
  styleUrls: ['./grn.component.scss']
})
export class GrnComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Project_expenceComponent } from './project_expence.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [Project_expenceComponent]
})
export class Project_expenceModule { }

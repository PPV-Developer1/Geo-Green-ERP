import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-project_expence',
  templateUrl: './project_expence.component.html',
  styleUrls: ['./project_expence.component.scss']
})
export class Project_expenceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

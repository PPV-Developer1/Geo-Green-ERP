import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Po_viewComponent } from './po_view.component';

@NgModule({
  imports: [
    CommonModule,
    NgModule
  ],
  declarations: [Po_viewComponent]
})
export class Po_viewModule { }
